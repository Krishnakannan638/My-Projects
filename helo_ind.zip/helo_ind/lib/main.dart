import 'package:flutter/material.dart';
import 'package:helo_ind/Screens/login_screen.dart';
import 'package:helo_ind/Screens/profile_screen.dart';

import 'Screens/home_screen.dart';
import 'Widgets/home.dart';
import 'Widgets/loginpage.dart';

void main() {
  runApp(Helo_IND());
}

class Helo_IND extends StatelessWidget {
  Helo_IND({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Login(),
    );
  }
}

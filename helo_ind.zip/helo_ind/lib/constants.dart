const String appName = "Helo_IND";
const String slogan = "Entertainment_App";
const String loginString = "LOGIN";
const String accountName = "Krishnaa";
const String accountEmail = "krishnakannan8011@gmail.com";

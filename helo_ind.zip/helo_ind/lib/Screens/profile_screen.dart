import 'package:flutter/material.dart';
import 'package:helo_ind/constants.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          toolbarHeight: 80,
          backgroundColor: Colors.orange,
          actions: [
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: Icon(Icons.share),
            ),
            Padding(
                padding: const EdgeInsets.all(15.0),
                child: Icon(Icons.settings)),
          ],
        ),
        body: Container(
          height: 500,
          child: Image.network("src"),
        ));
  }
}

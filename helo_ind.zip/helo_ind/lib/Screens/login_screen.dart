import 'package:flutter/material.dart';
import 'package:helo_ind/constants.dart';
import 'package:helo_ind/Screens/home_screen.dart';
import 'package:helo_ind/main.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Center(
          child: Container(
            decoration: BoxDecoration(
                color: Colors.limeAccent,
                borderRadius: BorderRadius.circular(15)),
            height: 450,
            child: Column(
              children: [
                Center(
                  child: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Text(appName,
                        style: TextStyle(
                            fontSize: 23, fontWeight: FontWeight.bold)),
                  ),
                ),
                Center(
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text(slogan,
                        style: TextStyle(
                            fontSize: 15, fontWeight: FontWeight.bold)),
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                      color: Color.fromARGB(255, 247, 243, 243),
                      borderRadius: BorderRadius.circular(15)),
                  margin: EdgeInsets.symmetric(vertical: 60),
                  width: 220,
                  height: 60,
                ),
                Container( 
                  decoration: BoxDecoration(
                      color: Color.fromARGB(255, 247, 243, 243),
                      borderRadius: BorderRadius.circular(15)),
                  margin: EdgeInsets.symmetric(vertical: 10),
                  height: 60,
                  width: 220,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

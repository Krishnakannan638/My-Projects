import 'package:flutter/material.dart';

class Home_Tab extends StatelessWidget {
  Home_Tab({
    Key? key,
  }) : super(key: key);
  var image =
      "https://www.wallsnapy.com/img_gallery/love-wallpaper-hd-for-mobile-free-download-5106380.png";
  var text = "Cat";
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
              padding: const EdgeInsets.all(5.0),
              child: Container(
                margin: EdgeInsets.all(10),
                height: 40,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Material(
                  color: Colors.transparent,
                  borderRadius: BorderRadius.circular(20),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(20),
                    onTap: () {},
                    child: Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Icon(Icons.search),
                        ),
                        Text("Seraching......")
                      ],
                    ),
                  ),
                ),
              )),
          SizedBox(
            height: 20,
          ),
          Padding(
            padding: const EdgeInsets.all(5.0),
            child: Text(
              "Category",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
            ),
          ),
          Container(
            height: 115,
            child: ListView.builder(
                shrinkWrap: true,
                scrollDirection: Axis.horizontal,
                itemCount: 8,
                itemBuilder: (context, index) {
                  return Column(
                    children: [
                      Mycard(image: image, text: text),
                      Mycard(image: image, text: text),
                      Mycard(image: image, text: text),
                      Mycard(image: image, text: text),
                    ],
                  );
                }),
          ),
          SizedBox(
            height: 20,
          ),
          Padding(
            padding: const EdgeInsets.all(15.0),
            child: Text(
              "Popular",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),
          Container(
            child: ListView.builder(
              shrinkWrap: true,
              scrollDirection: Axis.vertical,
              itemCount: 3,
              itemBuilder: (context, i) {
                return Column(
                  children: [
                    Container(
                      margin: EdgeInsets.all(20),
                      height: 300,
                      width: 360,
                      color: Colors.pink,
                      child: Image.network(
                        "https://i.pinimg.com/736x/66/b7/f6/66b7f6e5ad85cdfeab3459f2b5480407.jpg",
                        fit: BoxFit.fill,
                        height: 300,
                      ),
                    )
                  ],
                );
              },
            ),
          )
        ],
      ),
    );
  }
}

class Mycard extends StatelessWidget {
  const Mycard({
    Key? key,
    required this.image,
    required this.text,
  }) : super(key: key);

  final String image;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          margin: EdgeInsets.only(top: 5, bottom: 2, left: 8, right: 5),
          height: 70,
          width: 70,
          decoration: BoxDecoration(
              color: Colors.green, borderRadius: BorderRadius.circular(15)),
          child: Image.network(
            image,
            fit: BoxFit.fitWidth,
          ),
        ),
        Text(text)
      ],
    );
  }
}

import 'dart:html';

import 'package:flutter/material.dart';
import 'package:helo_ind/Screens/login_screen.dart';
import 'package:helo_ind/Screens/profile_screen.dart';
import 'package:helo_ind/Screens/tabs/home_tab.dart';

import '../constants.dart';

class HomePage extends StatefulWidget {
  HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  var Screens = [Home_Tab(), LoginScreen(), ProfilePage()];
  var index = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 80,
        backgroundColor: Colors.orange,
        /*leading: Icon(Icons.menu),*/
        title: Text("Helo_IND"),
        actions: const [
          Padding(
            padding: EdgeInsets.all(15.0),
            child: Icon(Icons.currency_rupee_sharp),
          ),
          Padding(
            padding: EdgeInsets.all(15.0),
            child: Icon(Icons.contact_page, color: Colors.white),
          ),
        ],
      ),
      drawer: Drawer(
        elevation: 16.0,
        child: Column(children: const [
          UserAccountsDrawerHeader(
            accountName: Text(accountName),
            accountEmail: Text(accountEmail),
            currentAccountPicture:
                CircleAvatar(backgroundColor: Colors.white, child: Text("KK")),
          ),
          ListTile(
            title: Text('Manage Account'),
            leading: Icon(Icons.account_box),
          ),
          Divider(
            height: 0.1,
          ),
          ListTile(
            title: Text('Language'),
            leading: Icon(Icons.language),
          ),
          Divider(
            height: 0.1,
          ),
          ListTile(
            title: Text('Privacy Policy'),
            leading: Icon(Icons.privacy_tip),
          ),
          Divider(
            height: 0.1,
          ),
          ListTile(
            title: Text('Help Feedback'),
            leading: Icon(Icons.feedback),
          ),
          Divider(
            height: 0.1,
          ),
          ListTile(
            title: Text('Setting'),
            leading: Icon(Icons.settings),
          ),
          Divider(
            height: 0.1,
          ),
        ]),
      ),
      body: Screens[index],
      bottomNavigationBar: Container(
        color: Colors.white,
        height: 60,
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
          Icon(Icons.home),
          Icon(Icons.video_library),
          Icon(
            Icons.add_a_photo,
            color: Color.fromARGB(255, 247, 32, 4),
            size: 50.0,
          ),
          Icon(Icons.notification_add),
          InkWell(
              onTap: () {
                setState(() {
                  index = 3;
                });
              },
              child: Icon(Icons.contacts)),
        ]),
      ),
    );
  }
}

import 'package:flutter/material.dart';

class Login extends StatelessWidget {
  const Login({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        margin: EdgeInsets.only(top: 150, right: 200),
        height: 500,
        color: Colors.grey,
        child: Column(children: [
          Container(
            //margin: EdgeInsets.all(30),
            height: 300,
            width: 500,
            color: Colors.yellow,
          )
        ]),
      ),
    );
  }
}

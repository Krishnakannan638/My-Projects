package com.example.helo_ind

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
